let humanScore = 0;
let computerScore = 0;
let currentRoundNumber = 1;

// Write your code below:

